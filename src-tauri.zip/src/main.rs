// Prevents additional console window on Windows in release, DO NOT REMOVE!!
#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]

mod dns_tester;

#[tauri::command]
async fn run_dns_benchmark(domain: String) -> Vec<dns_tester::DnsTestResult> {
    dns_tester::perform_dns_benchmark(domain, None, None).await
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![run_dns_benchmark])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}